'use strict';

module.exports.checkInventory = async (event) => {
  return "Stocks Available"
};

module.exports.calculateTotal = async (event) => {
  return 100
};
